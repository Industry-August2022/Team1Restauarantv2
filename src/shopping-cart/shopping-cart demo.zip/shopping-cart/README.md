# Shopping Cart

A Pen created on CodePen.io. Original URL: [https://codepen.io/bartveneman/pen/kyMjao](https://codepen.io/bartveneman/pen/kyMjao).

My entry for the pattern rodeo no. 7. I am fully aware that there is some heavy DOM-traversing and that the overall js construction is poor, but it works for now.
Uses Zepto, Mustache en Justify Grid. Products can be pulled in as JSON, but in this case hardcoded.